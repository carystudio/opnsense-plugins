#include <dirent.h>


enum {
        PSSCAN_PID      = 1 << 0,
        PSSCAN_PPID     = 1 << 1,
        PSSCAN_PGID     = 1 << 2,
        PSSCAN_SID      = 1 << 3,
        PSSCAN_UIDGID   = 1 << 4,
        PSSCAN_COMM     = 1 << 5,
        /* PSSCAN_CMD      = 1 << 6, - use read_cmdline instead */
        PSSCAN_ARGV0    = 1 << 7,
        /* PSSCAN_EXE      = 1 << 8, - not implemented */
        PSSCAN_STATE    = 1 << 9,
        PSSCAN_VSZ      = 1 << 10,
        PSSCAN_RSS      = 1 << 11,
        PSSCAN_STIME    = 1 << 12,
        PSSCAN_UTIME    = 1 << 13,
        PSSCAN_TTY      = 1 << 14,
        PSSCAN_SMAPS    = (1 << 15) * 0,
        PSSCAN_ARGVN    = (1 << 16) * 1,
        PSSCAN_START_TIME = 1 << 18,
        /* These are all retrieved from proc/NN/stat in one go: */
        PSSCAN_STAT     = PSSCAN_PPID | PSSCAN_PGID | PSSCAN_SID
                        | PSSCAN_COMM | PSSCAN_STATE
                        | PSSCAN_VSZ | PSSCAN_RSS
                        | PSSCAN_STIME | PSSCAN_UTIME | PSSCAN_START_TIME
                        | PSSCAN_TTY,
};


typedef struct procps_status_t {
        DIR *dir;
        unsigned char shift_pages_to_bytes;
        unsigned char shift_pages_to_kb;
/* Fields are set to 0/NULL if failed to determine (or not requested) */
        unsigned int argv_len;
        char *argv0;
        /* Everything below must contain no ptrs to malloc'ed data:
         * it is memset(0) for each process in procps_scan() */
        unsigned long vsz, rss; /* we round it to kbytes */
        unsigned long stime, utime;
        unsigned long start_time;
        unsigned pid;
        unsigned ppid;
        unsigned pgid;
        unsigned sid;
        unsigned uid;
        unsigned gid;
        unsigned tty_major,tty_minor;
        char state[4];
        /* basename of executable in exec(2), read from /proc/N/stat
         * (if executable is symlink or script, it is NOT replaced
         * by link target or interpreter name) */
        char comm[16];
        /* user/group? - use passwd/group parsing functions */
} procps_status_t;

#define ULLONG_MAX     (~0ULL)
#define UINT_MAX       (~0U)

#define PROCPS_BUFSIZE 1024
#ifndef offsetof
#define offsetof(p_type,field) ((size_t)&(((p_type *)0)->field))
#endif


int getIfIp(char *, char *);
int getIfNetmask(char *ifname, char *if_netmask);
void nsqreadline(char *buf,FILE *fp);
int CsteSystem(char *command, int printFlag);
void getStrFromFile(char* path, char* tmpbuf);
int getNthValueSafe(int index, char *value, char delimit, char *result, int len);
int pids(char *appname);
pid_t* find_pid_by_name(const char *procName);
procps_status_t* procps_scan(procps_status_t* sp, int flags);
void* xzalloc(size_t size);
static int comm_match(procps_status_t *p, const char *procName);
const char* bb_basename(const char *name);
void* xrealloc_vector_helper(void *vector, unsigned sizeof_and_shift, int idx);
static procps_status_t* alloc_procps_scan(void);
void free_procps_scan(procps_status_t* sp);
unsigned bb_strtou(const char *arg, char **endp, int base);
unsigned long long bb_strtoull(const char *arg, char **endp, int base);
static int read_to_buf(const char *filename, void *buf);
void BUG_comm_size(void);
void* xrealloc(void *ptr, size_t size);
static unsigned long long ret_ERANGE(void);
static unsigned long long handle_errors(unsigned long long v, char **endp, char *endptr);


