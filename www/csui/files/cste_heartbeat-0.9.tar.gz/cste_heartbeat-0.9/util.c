#include <net/if.h>
#include <sys/sockio.h> 
#include <netinet/in.h> 
#include <string.h>
#include <arpa/inet.h> 
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>   
#include <sys/wait.h>  
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <ctype.h>
#include "util.h"

int getIfIp(char *ifname, char *if_addr)
{
        struct ifreq ifr;
        int skfd = 0;

        if((skfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
                //error(E_L, E_LOG, T("getIfIp: open socket error"));
                return -1;
        }

        strncpy(ifr.ifr_name, ifname, IF_NAMESIZE);
        if (ioctl(skfd, SIOCGIFADDR, &ifr) < 0) {
                close(skfd);
                //error(E_L, E_LOG, T("getIfIp: ioctl SIOCGIFADDR error for %s"), ifname);
                return -1;
        }
        strcpy(if_addr, inet_ntoa(((struct sockaddr_in *)&ifr.ifr_addr)->sin_addr));

        close(skfd);
        return 0;
}

int getIfNetmask(char *ifname, char *if_netmask){
	struct ifreq ifr;
        int skfd = 0;

        if((skfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
                //error(E_L, E_LOG, T("getIfIp: open socket error"));
                return -1;
        }

        strncpy(ifr.ifr_name, ifname, IF_NAMESIZE);
        if (ioctl(skfd, SIOCGIFNETMASK, &ifr) < 0) {
                close(skfd);
                //error(E_L, E_LOG, T("getIfNetmask: ioctl SIOCGIFNETMASK error for %s"), ifname);
                return -1;
        }
        strcpy(if_netmask, inet_ntoa(((struct sockaddr_in *)&ifr.ifr_addr)->sin_addr));
        close(skfd);

        return 0;
}


void nsqreadline(char *buf,FILE *fp)
{
        char tmp[2] = {0};
        int i = 0;
        if(fp == NULL)
                buf = NULL;

        while(!feof(fp)){
                fread(tmp,1,1,fp);
                if(tmp[0] != '\n')
                        buf[i++] = tmp[0];
                else
                        break;
        }
}

int CsteSystem(char *command, int printFlag)
{
        int pid = 0, status = 0;

    if( !command )
    {
        printf("CsteSystem: Null Command, Error!");
        return -1;
    }

        pid = fork();
        if ( pid == -1 )
        {
                return -1;
        }

        if ( pid == 0 )
        {
        char *argv[4];
        argv[0] = "sh";
        argv[1] = "-c";
        argv[2] = command;
        argv[3] = 0;
        if (printFlag)
        {
                printf("[system]: %s\r\n", command);
        }
        execv("/bin/sh", argv);
        exit(127);
        }

        /* wait for child process return */
        do
        {
                if ( waitpid(pid, &status, 0) == -1 )
        {
                if ( errno != EINTR )
                {
                return -1;
            }
            }
        else
        {
                return status;
                }
        } while ( 1 );

        return status;
}



void getStrFromFile(char* path, char* tmpbuf)
{
        char tmp[2] = {0};
        FILE *fp;
        int i = 0,flag=0;
        strcpy(tmpbuf,"");
        fp = fopen(path, "r");
        if (!fp) {
                fprintf(stderr, "Read file error:%s!\n",path);
                return ;
        }
        while(!feof(fp)){
                fread(tmp,1,1,fp);
                tmpbuf[i++] = tmp[0];
        }

        //del "\n\r"
        while(i>0){
                if(tmpbuf[i]=='\r' || tmpbuf[i]=='\n'){
                        flag=1;
                        i--;
                }else{
                        if(flag==1)
                                tmpbuf[i+1]='\0';
                        break;
                }
        }

        fclose(fp);
        return;
}


int getNthValueSafe(int index, char *value, char delimit, char *result, int len)
{
    int i=0, result_len=0;
    char *begin, *end;

    if(!value || !result || !len)
        return -1;

    begin = value;
    end = strchr(begin, delimit);

    while(i<index && end){
        begin = end+1;
        end = strchr(begin, delimit);
        i++;
    }

    //no delimit
    if(!end){
                if(i == index){
                        end = begin + strlen(begin);
                        result_len = (len-1) < (end-begin) ? (len-1) : (end-begin);
                }else
                        return -1;
        }else
                result_len = (len-1) < (end-begin)? (len-1) : (end-begin);

        memcpy(result, begin, result_len );
        *(result+ result_len ) = '\0';

        return 0;
}

#define xrealloc_vector(vector, shift, idx) \
        xrealloc_vector_helper((vector), (sizeof((vector)[0]) << 8) + (shift), (idx))


pid_t* find_pid_by_name(const char *procName)
{
        pid_t* pidList;
        int i = 0;
        procps_status_t* p = NULL;

        pidList = xzalloc(sizeof(*pidList));
        while ((p = procps_scan(p, PSSCAN_PID|PSSCAN_COMM|PSSCAN_ARGVN))) {
                if (comm_match(p, procName)
                /* or we require argv0 to match (essential for matching reexeced /proc/self/exe)*/
                 || (p->argv0 && strcmp(bb_basename(p->argv0), procName) == 0)
                /* TOOD: we can also try /proc/NUM/exe link, do we want that? */
                ) {
                        pidList = xrealloc_vector(pidList, 2, i);
                        pidList[i++] = p->pid;
                }
        }

        pidList[i] = 0;
        return pidList;
}



int pids(char *appname)
{
        pid_t *pidList;
        pid_t *pl;
        int count = 0;

        pidList = find_pid_by_name(appname);
        for (pl = pidList; *pl; pl++) {
                count++;
        }
        free(pidList);

        if (count)
                return 1;
        else
                return 0;
}


void free_procps_scan(procps_status_t* sp)
{
        closedir(sp->dir);
        free(sp->argv0);
        free(sp);
}



procps_status_t* procps_scan(procps_status_t* sp, int flags)
{
        struct dirent *entry;
        char buf[PROCPS_BUFSIZE];
        char filename[sizeof("/proc//cmdline") + sizeof(int)*3];
        char *filename_tail;
        long tasknice;
        unsigned pid;
        int n;
        struct stat sb;

        if (!sp)
                sp = alloc_procps_scan();

        for (;;) {
                entry = readdir(sp->dir);
                if (entry == NULL) {
                        free_procps_scan(sp);
                        return NULL;
                }
                pid = bb_strtou(entry->d_name, NULL, 10);
                if (errno)
                        continue;

                /* After this point we have to break, not continue
                 * ("continue" would mean that current /proc/NNN
                 * is not a valid process info) */

                memset(&sp->vsz, 0, sizeof(*sp) - offsetof(procps_status_t, vsz));

                sp->pid = pid;
                if (!(flags & ~PSSCAN_PID)) break;

                filename_tail = filename + sprintf(filename, "/proc/%d", pid);

                if (flags & PSSCAN_UIDGID) {
                        if (stat(filename, &sb))
                                break;
                        /* Need comment - is this effective or real UID/GID? */
                        sp->uid = sb.st_uid;
                        sp->gid = sb.st_gid;
                }

                if (flags & PSSCAN_STAT) {
                        char *cp, *comm1;
                        int tty;
                        unsigned long vsz, rss;

                        /* see proc(5) for some details on this */
                        strcpy(filename_tail, "/stat");
                        n = read_to_buf(filename, buf);
                        if (n < 0)
                                break;
                        cp = strrchr(buf, ')'); /* split into "PID (cmd" and "<rest>" */
                        /*if (!cp || cp[1] != ' ')
                                break;*/
                        cp[0] = '\0';
                        if (sizeof(sp->comm) < 16)
                                BUG_comm_size();
                        comm1 = strchr(buf, '(');
                        /*if (comm1)*/
                                strncpy(sp->comm, comm1 + 1, sizeof(sp->comm));

                        n = sscanf(cp+2,
                                "%c %u "               /* state, ppid */
                                "%u %u %d %*s "        /* pgid, sid, tty, tpgid */
                                "%*s %*s %*s %*s %*s " /* flags, min_flt, cmin_flt, maj_flt, cmaj_flt */
                                "%lu %lu "             /* utime, stime */
                                "%*s %*s %*s "         /* cutime, cstime, priority */
                                "%ld "                 /* nice */
                                "%*s %*s "             /* timeout, it_real_value */
                                "%lu "                 /* start_time */
                                "%lu "                 /* vsize */
                                "%lu "                 /* rss */
                        /*      "%lu %lu %lu %lu %lu %lu " rss_rlim, start_code, end_code, start_stack, kstk_esp, kstk_eip */
                        /*      "%u %u %u %u "         signal, blocked, sigignore, sigcatch */
                        /*      "%lu %lu %lu"          wchan, nswap, cnswap */
                                ,
                                sp->state, &sp->ppid,
                                &sp->pgid, &sp->sid, &tty,
                                &sp->utime, &sp->stime,
                                &tasknice,
                                &sp->start_time,
                                &vsz,
                                &rss);
                        if (n != 11)
                                break;
                        /* vsz is in bytes and we want kb */
                        sp->vsz = vsz >> 10;
                        /* vsz is in bytes but rss is in *PAGES*! Can you believe that? */
                        sp->rss = rss << sp->shift_pages_to_kb;
                        sp->tty_major = (tty >> 8) & 0xfff;
                        sp->tty_minor = (tty & 0xff) | ((tty >> 12) & 0xfff00);

                        if (sp->vsz == 0 && sp->state[0] != 'Z')
                                sp->state[1] = 'W';
                        else
                                sp->state[1] = ' ';
                        if (tasknice < 0)
                                sp->state[2] = '<';
                        else if (tasknice) /* > 0 */
                                sp->state[2] = 'N';
                        else
                                sp->state[2] = ' ';

                }

                if (flags & (PSSCAN_ARGV0|PSSCAN_ARGVN)) {
                        free(sp->argv0);
                        sp->argv0 = NULL;
                        strcpy(filename_tail, "/cmdline");
                        n = read_to_buf(filename, buf);
                        if (n <= 0)
                                break;
                        if (flags & PSSCAN_ARGVN) {
                                sp->argv_len = n;
                                sp->argv0 = malloc(n + 1);
                                memcpy(sp->argv0, buf, n + 1);
                                /* sp->argv0[n] = '\0'; - buf has it */
                        } else {
                                sp->argv_len = 0;
                                sp->argv0 = strdup(buf);
                        }
                }
                break;
        }
        return sp;
}


void* xzalloc(size_t size)
{
        void *ptr = malloc(size);
        memset(ptr, 0, size);
        return ptr;
}


static int comm_match(procps_status_t *p, const char *procName)
{
        int argv1idx;

        /* comm does not match */
        if (strncmp(p->comm, procName, 15) != 0)
                return 0;

        /* in Linux, if comm is 15 chars, it may be a truncated */
        if (p->comm[14] == '\0') /* comm is not truncated - match */
                return 1;

        /* comm is truncated, but first 15 chars match.
         * This can be crazily_long_script_name.sh!
         * The telltale sign is basename(argv[1]) == procName. */

        if (!p->argv0)
                return 0;

        argv1idx = strlen(p->argv0) + 1;
        if (argv1idx >= p->argv_len)
                return 0;

        if (strcmp(bb_basename(p->argv0 + argv1idx), procName) != 0)
                return 0;

        return 1;
}


const char* bb_basename(const char *name)
{
        const char *cp = strrchr(name, '/');
        if (cp)
                return cp + 1;
        return name;
}


void* xrealloc_vector_helper(void *vector, unsigned sizeof_and_shift, int idx)
{
        int mask = 1 << (unsigned char)sizeof_and_shift;

        if (!(idx & (mask - 1))) {
                sizeof_and_shift >>= 8; /* sizeof(vector[0]) */
                vector = xrealloc(vector, sizeof_and_shift * (idx + mask + 1));
                memset((char*)vector + (sizeof_and_shift * idx), 0, sizeof_and_shift * (mask + 1));
        }
        return vector;
}


static procps_status_t* alloc_procps_scan(void)
{
        unsigned n = getpagesize();
        procps_status_t* sp = xzalloc(sizeof(procps_status_t));
        sp->dir = opendir("/proc");
        while (1) {
                n >>= 1;
                if (!n) break;
                sp->shift_pages_to_bytes++;
        }
        sp->shift_pages_to_kb = sp->shift_pages_to_bytes - 10;
        return sp;
}



unsigned bb_strtou(const char *arg, char **endp, int base)
{
        unsigned long v;
        char *endptr;

        if (!isalnum(arg[0])) return ret_ERANGE();
        errno = 0;
        v = strtoul(arg, &endptr, base);
        if (v > UINT_MAX) return ret_ERANGE();
        return handle_errors(v, endp, endptr);
}

unsigned long long bb_strtoull(const char *arg, char **endp, int base)
{
        unsigned long long v;
        char *endptr;

        /* strtoul("  -4200000000") returns 94967296, errno 0 (!) */
        /* I don't think that this is right. Preventing this... */
        if (!isalnum(arg[0])) return ret_ERANGE();

        /* not 100% correct for lib func, but convenient for the caller */
        errno = 0;
        v = strtoull(arg, &endptr, base);
        return handle_errors(v, endp, endptr);
}


static int read_to_buf(const char *filename, void *buf)
{
        int fd;
        /* open_read_close() would do two reads, checking for EOF.
         * When you have 10000 /proc/$NUM/stat to read, it isn't desirable */
        int ret = -1;
        fd = open(filename, O_RDONLY);
        if (fd >= 0) {
                ret = read(fd, buf, PROCPS_BUFSIZE-1);
                close(fd);
        }
        ((char *)buf)[ret > 0 ? ret : 0] = '\0';
        return ret;
}


void BUG_comm_size(void)
{
}


void* xrealloc(void *ptr, size_t size)
{
        ptr = realloc(ptr, size);
        if (ptr == NULL && size != 0)
                perror("no memory");
        return ptr;
}


static unsigned long long ret_ERANGE(void)
{
        errno = ERANGE; /* this ain't as small as it looks (on glibc) */
        return ULLONG_MAX;
}


static unsigned long long handle_errors(unsigned long long v, char **endp, char *endptr)
{
        if (endp) *endp = endptr;

        /* errno is already set to ERANGE by strtoXXX if value overflowed */
        if (endptr[0]) {
                /* "1234abcg" or out-of-range? */
                if (isalnum(endptr[0]) || errno)
                        return ret_ERANGE();
                /* good number, just suspicious terminator */
                errno = EINVAL;
        }
        return v;
}



