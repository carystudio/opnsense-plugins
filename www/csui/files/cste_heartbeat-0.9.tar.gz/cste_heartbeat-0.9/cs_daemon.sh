#!/bin/sh  
DATE=$(date "+%G-%m-%d %H:%M:%S")
while true  
do  
	if ps aux | grep -v grep | grep cste_heartbeat >/dev/null 2>&1  
	then   
		echo  "$DATE cste_heartbeat the process is runing!" >/dev/null
	else 
		/usr/local/bin/cste_heartbeat &
		echo "$DATE  cste_heartbeat the process does not exist!" >> /var/log/cste_heartbeat_error.log
	fi   
	sleep 15  
done  
