#ifndef __MANAGEAGENT__
#define __MANAGEAGENT__

#include <sys/ioctl.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <net/if.h>
#include <sys/socket.h>
#include <cste_mysql.h>

struct heartbeat_agent{
	int socket;
	struct sockaddr_in address;
	struct sockaddr_in RecvAddr;
	MYSQL *my_con;
};


typedef enum {
	HB_FALSE = 0,
	HB_TRUE = 1
} HB_BOOL;

#define SIG_ACRESET     29
#define SIG_BROADCAST 30
#define SIG_SETAPIP 31

#define T(s)                            s

#if defined(SUPPORT_CSTE_DEBUG)
#define CSTE_PRINT_CMD       1
#else
#define CSTE_PRINT_CMD       0
#endif

#define SMALL_BUF_SIZE	8

#define TEMP_BUF_SIZE 128

#define CMD_BUF_SIZE 256

#define MAX_BUF_SIZE 4096

#define HEART_BEAT_PORT 42999
#define BROADCAST_SPORT 42997
#define BROADCAST_DPORT 42998

#define BROADCAST_IP "255.255.255.255"

#define DEFAULT_HTTP_PORT	80

#define SESSIONOVER "SessionOver"

#define ACTION_GETKEYLIST  "GetKeyList"
#define ACTION_BROADCASTAP "broadcastAp"
#define ACTION_SETAPIP     "setIp"
#define ACTION_SCANAP      "scanAp"


#define ACVERSION "1.0"

#define DEFAULT_ICS_TIMEOUT 1

#define DEFAULT_ICS_RETYR 	3

typedef char               char_t;

typedef enum {
	QUICKSETTING=0,
	HARDWARE_AC = 1,
	GATEWAY_AC = 2,
	CLOUDAC
} AC_TYPE;


#endif
