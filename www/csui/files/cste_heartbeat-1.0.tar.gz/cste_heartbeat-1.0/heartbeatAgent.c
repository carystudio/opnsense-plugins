#include "jobqueen.h"
#include "heartbeatAgent.h"
#include "util.h"
#include <cste_mysql.h>
#include <signal.h>
#include <setjmp.h>
#include <assert.h>
#include <unistd.h>

JOB_BOOL gRun;
struct sockaddr_in broad_cast_addr;
int broad_sk = -1;


char_t *websGetVar(cJSON *object, char_t *var, char_t *defaultGetValue)
{
        cJSON   *sp;

    assert(var && *var);

        if ((sp = cJSON_GetObjectItem(object, var)) != NULL) {
                if (sp->valuestring)
                {
                        return sp->valuestring;
                }
                else if (sp->type==cJSON_False)
                {
                        return "0";
                }
                else if (sp->type==cJSON_True)
                {
                        return "1";
                }
                else if (sp->type==cJSON_Number)
                {
                        static char_t tmp[16] = { 0 };
                        sprintf(tmp, "%d", sp->valueint);
                        return tmp;
                }
                else if (!sp->valuestring)
                        return defaultGetValue;
                else
                {
                        return "";
                }
        }
        return defaultGetValue;
}


void MainInit(struct heartbeat_agent *agent)
{
	gRun = J_TRUE;
	memset(agent,0,sizeof(struct heartbeat_agent));
}

void print_mem (unsigned char *p, int k)
{
	int i;
	printf("\n");

	for (i = 0; i < k; i++)
	{
		printf("%02x ", *p++);

		if ((i + 1) % 16 == 0) printf("\n");
	}

	printf("\n");
}


void MainGracefulExit(int sig)
{
	gRun = J_FALSE;
	(void) signal(SIGTERM, SIG_IGN);
}
static int getLanIfName(char *lanname)  
{  
	char   buff[256];
	char *ifnode,*ifend;
    FILE *fp;  

    fp = fopen("/conf/config.xml", "r");
    if(fp == NULL)
    {
        printf("open the config.xml error!\n");
		strcpy(lanname,"em0");
        return -1;
    }
	while (fgets(buff, sizeof(buff), fp) != NULL) {
		if (strstr(buff,"<opnsense>")) {
			while (fgets(buff, sizeof(buff), fp) != NULL) {
				if (strstr(buff,"<interfaces>")) {
					while (fgets(buff, sizeof(buff), fp) != NULL) {
						if (strstr(buff,"<lan>")) {
							while (fgets(buff, sizeof(buff), fp) != NULL) {
								if (strstr(buff,"<if>")) {//<if>em0</if>
									ifnode = strchr(buff,'>');
									ifend = strchr(ifnode,'<');
									strncpy(lanname,ifnode+1,ifend-ifnode-1);
									lanname[ifend-ifnode-1] = '\0';
									goto end;
								}
							}	
						}						
					}
				
				}
			}
		}
	}
end:	
	if(!strlen(lanname)){
		strcpy(lanname,"em0");
	}
	fclose(fp);
    return 0;  
} 
int isSameNetwork(char *AcIp, char *AcMask, char *SelfIp, char *SelfMask)
{
	struct in_addr inIp, inMask;
	struct in_addr myIp, myMask, mask;
	unsigned int inIpVal, inMaskVal, myIpVal, myMaskVal, maskVal;
	
	if ( !inet_aton(AcIp, &inIp) ) {
		return 0;
	}
	
	if ( !inet_aton(AcMask, &inMask) ) {
		return 0;
	}
	
	memcpy(&inIpVal, &inIp, 4);
	memcpy(&inMaskVal, &inMask, 4);

	if ( !inet_aton(SelfIp, &myIp) ) {
		return 0;
	}
	
	if ( !inet_aton(SelfMask, &myMask) ) {
		return 0;
	}		
	
	memcpy(&myIpVal, &myIp, 4);
	memcpy(&myMaskVal, &myMask, 4);
	memcpy(&maskVal,myMaskVal>inMaskVal?&myMaskVal:&inMaskVal,4);
	
	if((inIpVal & maskVal) == (myIpVal & maskVal))
	{
		return 1;
	}

	return 0;
}

int  HeartBeatSockInit(struct heartbeat_agent *agent)
{
	int nReuseFlag = 1;
	if ((agent->socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0)
	{
			printf("CsteHeartBeatSockInit Error Creating Socket\n");
			return HB_FALSE;
	}
	
	memset(&(agent->address),0,sizeof(agent->address));
	agent->address.sin_family = AF_INET;
	
	agent->address.sin_addr.s_addr = htonl(INADDR_ANY);

	agent->address.sin_port = htons(HEART_BEAT_PORT);

	if(setsockopt(agent->socket, SOL_SOCKET, SO_REUSEADDR, &nReuseFlag, sizeof(int)) < 0)
	{ 
		printf("CsteHeartBeatSockInit:Set socket option	failed!\n "); 
		close(agent->socket); 
		return HB_FALSE; 
	} 

	if((bind(agent->socket, (struct sockaddr *)&agent->address, sizeof(agent->address))) < 0)
	{
		printf("CsteHeartBeatSockInit:Error Binding Socket \n");
		return HB_FALSE;
	}

	return HB_TRUE;
}

void MAC17_TO_MAC6( unsigned char * MAC_17, unsigned char * MAC_6)
{
	int i = 0;
	memset(MAC_6,0,MYSQL_MAC_LEN);	
	for(i = 0; i < MYSQL_MAC_LEN; i++)
	{		
		MAC_6[i] = strtoul((unsigned char *)(&(MAC_17[i*3])), 0, 16);
	}
	return;

}

HB_BOOL check_apstate_by_mac(struct heartbeat_agent *agent,char *mac_str)
{
	MYSQL *my_con;
	int apstate=HB_FALSE;
	int config = HB_FALSE;
	HB_BOOL result;
	cste_mysqlexec(&(agent->my_con),"update %s set %s=0 where %s='%s';",TBL_ID_TONAME(MYSQL_APLIST_TABLE),MYSQL_HFTIMES_KEY_NAME,MYSQL_MAC_KEY_NAME,mac_str);	
	cste_mysqlgetint(&(agent->my_con), MYSQL_APLIST_TABLE ,MSYQL_APSTATE_KEY_NAME,MYSQL_MAC_KEY_NAME,mac_str,&apstate);
	if(AP_CONFIG_OK_VALUE == apstate)
	{
		result = HB_FALSE;
	}else
	{
		result = HB_TRUE;
	}
	return result;
}

void send_response_to_ap(struct heartbeat_agent* agent,unsigned char *RecvMsgArray,HB_BOOL result)
{
	int sendbyte = 0;
	int size = MYSQL_MAC_LEN+2;
	char sendMsg[MYSQL_MAC_LEN+2] = {0}; 

	memcpy(sendMsg,RecvMsgArray,MYSQL_MAC_LEN);
	sendMsg[MYSQL_MAC_LEN] = GATEWAY_AC;
	sendMsg[MYSQL_MAC_LEN+1] = result;
	
	printf("send_response_to_ap %s\n",inet_ntoa(agent->address.sin_addr));
	
	sendbyte = sendto(agent->socket, sendMsg, size, 0, (struct sockaddr *)&agent->address, sizeof(agent->address));
	if (sendbyte != size)
	{
		printf("send_response_to_ap:sent a different number of bytes than expected, send %d byte \n", sendbyte);
	}
	return;
}


void HeartBeatProcessReceiveMsg(struct heartbeat_agent* agent,unsigned char *RecvMsgArray,int byteReceived)
{
	char mac_str[MYSQL_MAC_STR_LEN]= {0};
	HB_BOOL result = HB_FALSE;
	
	if(MYSQL_MAC_LEN == byteReceived)
	{
		snprintf(mac_str,MYSQL_MAC_STR_LEN,"%02X:%02X:%02X:%02X:%02X:%02X",*RecvMsgArray,*(RecvMsgArray+1),*(RecvMsgArray+2),*(RecvMsgArray+3),*(RecvMsgArray+4),*(RecvMsgArray+5));
		result = check_apstate_by_mac(agent,mac_str);
		send_response_to_ap(agent,RecvMsgArray,result);
	}
	
}

void HeartBeatReceive(struct heartbeat_agent* agent)
{

	unsigned char RecvMsgArray[TEMP_BUF_SIZE];
	int RecvAddrLen = sizeof(struct sockaddr_in);
	int byteReceived;
	struct sockaddr_in RecvAddr;
					
	memset(RecvMsgArray,0,TEMP_BUF_SIZE);
	byteReceived = recvfrom(agent->socket, RecvMsgArray, TEMP_BUF_SIZE, 0, (struct sockaddr *)&RecvAddr, &RecvAddrLen);

	if(byteReceived < 0)
	{
		printf("HeartBeatReceive: Receive Msg Error\n");
		return;
	}

	agent->address.sin_addr = RecvAddr.sin_addr;
	agent->address.sin_port = RecvAddr.sin_port;
	
	HeartBeatProcessReceiveMsg(agent,RecvMsgArray,byteReceived);
	return;
}

void HeartBroadCastProcessReceiveMsg(struct heartbeat_agent* agent,char *RecvMsgArray,int byteReceived)
{
	
	int  svnnum_v = 0,APSTATE = 0,apid = 0;
	cJSON * root_recv = NULL;
	char ifName[8] = {0},APMAC[MYSQL_MAC_STR_LEN] = {0},acIp[16] = {0}, acMask[16] = {0},tmp[16] = {0};

	root_recv=cJSON_Parse(RecvMsgArray);
	if(root_recv==NULL){
		printf("[HeartScanReceive]Scan Recv data not json!\n");
		return;
	}

	char *apmac = websGetVar(root_recv, T("mac"), T(""));
	char *ipaddr = websGetVar(root_recv, T("ip"), T(""));
	char *netmask = websGetVar(root_recv, T("mask"), T(""));
	char *aptype = websGetVar(root_recv, T("type"), T(""));
	char *csid = websGetVar(root_recv, T("csid"), T(""));
	char *softver = websGetVar(root_recv, T("softVer"), T(""));
	char *svnnum = websGetVar(root_recv, T("svnNum"), T(""));
	char *model = websGetVar(root_recv, T("softModel"), T(""));
	char *action = websGetVar(root_recv, T("action"), T(""));
	char *version = websGetVar(root_recv, T("version"), T(""));

	svnnum_v = atoi(svnnum);
	if(strcmp(action,ACTION_BROADCASTAP)||strcmp(version,ACVERSION))
	{
		cJSON_Delete(root_recv);
		return;
	}
	getLanIfName(ifName);
	getIfIp(ifName, acIp);
	getIfNetmask(ifName, acMask);

	cste_mysqlgetint(&(agent->my_con),MYSQL_APLIST_TABLE,MSYQL_APSTATE_KEY_NAME,MYSQL_MAC_KEY_NAME,apmac,&APSTATE);

	if(isSameNetwork(acIp,acMask, ipaddr, netmask)==1)
	{
		update_apstate(NETWORK_STATE,MY_CONFIG_OK,&APSTATE);
	}
	else
	{
		update_apstate(NETWORK_STATE,MY_CONFIG_NEED,&APSTATE);
	}
//	printf("action_get_handler mac:%s state is %d",apmac,APSTATE);
	if(cste_mysqlgetstr(&(agent->my_con), MYSQL_APLIST_TABLE ,MYSQL_MAC_KEY_NAME,MYSQL_MAC_KEY_NAME,apmac,APMAC,MYSQL_MAC_STR_LEN))
	{
		/*update ap*/		
		cste_mysqlexec(&(agent->my_con),"update %s set ipaddr='%s',csid='%s',model='%s',svnnum='%d',softver='%s',aptype='%s' where apmac='%s';",
								TBL_ID_TONAME(MYSQL_APLIST_TABLE),ipaddr,csid,model,svnnum_v,softver,aptype,apmac);
		
	}else
	{
		/*new ap */		
		cste_mysqlexec(&(agent->my_con),"insert into %s (apmac,ipaddr,csid,model,svnnum,softver,aptype) values('%s','%s','%s','%s','%d','%s','%s');",
								TBL_ID_TONAME(MYSQL_APLIST_TABLE),apmac,ipaddr,csid,model,svnnum_v,softver,aptype);
		
		cste_mysqlgetint(&(agent->my_con),MYSQL_APLIST_TABLE,MYSQL_APID_KEY_NAME,MYSQL_MAC_KEY_NAME,apmac,&apid);
				
		cste_mysqlexec(&(agent->my_con),"insert into %s (apid,usefor) values('%d','%s');",TBL_ID_TONAME(MYSQL_WLAN_STATUS),apid,aptype);
		if(atoi(aptype)==1){
			cste_mysqlexec(&(agent->my_con),"insert into %s (apid,gid,country) values('%d','1', 'CN');",TBL_ID_TONAME(MYSQL_APSTATUS_WIFI0),apid);
		}else if(atoi(aptype)==2){
			cste_mysqlexec(&(agent->my_con),"insert into %s (apid,gid,country) values('%d','1', 'CN');",TBL_ID_TONAME(MYSQL_APSTATUS_WIFI1),apid);								
		}else{
			cste_mysqlexec(&(agent->my_con),"insert into %s (apid,gid,country) values('%d','1', 'CN');",TBL_ID_TONAME(MYSQL_APSTATUS_WIFI0),apid);
			cste_mysqlexec(&(agent->my_con),"insert into %s (apid,gid,country) values('%d','1', 'CN');",TBL_ID_TONAME(MYSQL_APSTATUS_WIFI1),apid);								
		}	
		
		update_apstate(RESET_COMMAND,MY_CONFIG_OK,&APSTATE);
		update_apstate(REBOOT_COMMAND,MY_CONFIG_OK,&APSTATE);
		update_apstate(UPGRADE_COMMAND,MY_CONFIG_OK,&APSTATE);
	}
	cste_mysqlexec(&(agent->my_con),"update %s set apstate='%d' where apmac='%s';",TBL_ID_TONAME(MYSQL_APLIST_TABLE),APSTATE,apmac);
	if(MyGetField32(APSTATE,NETWORK_STATE))
	{
		cste_mysqlexec(&(agent->my_con),"update %s set %s=0 where %s='%s';",TBL_ID_TONAME(MYSQL_APLIST_TABLE),MYSQL_HFTIMES_KEY_NAME,MYSQL_MAC_KEY_NAME,apmac);	
	}
	cJSON_Delete(root_recv);
}


void HeartBroadcastReceive(struct heartbeat_agent* agent)
{
	unsigned char RecvMsgArray[MAX_BUF_SIZE];
	int RecvAddrLen = sizeof(struct sockaddr_in);
	int byteReceived;
	struct sockaddr_in RecvAddr;
					
	memset(RecvMsgArray,0,MAX_BUF_SIZE);
	byteReceived = recvfrom(broad_sk, RecvMsgArray, MAX_BUF_SIZE, 0, (struct sockaddr *)&RecvAddr, &RecvAddrLen);

	if(byteReceived < 0)
	{
		printf("HeartBeatReceive: Receive Msg Error\n");
		return;
	}
//	printf("AP-rec:%s:%d,byte:%d\n%s\n",inet_ntoa(RecvAddr.sin_addr),ntohs(RecvAddr.sin_port),byteReceived,RecvMsgArray);
	if(ntohs(RecvAddr.sin_port)==BROADCAST_DPORT)
		HeartBroadCastProcessReceiveMsg(agent,RecvMsgArray,byteReceived);
	return;
}

char* mysql_printjson(MYSQL **my_con,char *query)
{
	char *result = NULL;
	char *output=NULL;
	char **fields =NULL;
	MYSQL_FIELD *my_field =NULL;
	MYSQL_ROW row;
	
	int  ret=0, index=0, nrow,ncol, i, j;
	cJSON *ApFoundArray, *root;

	ret = cste_mysqlgettable(my_con,query,&nrow,&ncol,&result);
	
	if((!ret)||(!nrow)||(!result))
	{
		goto noresult;
	}
	
	my_field = mysql_fetch_fields(result);
	if(!my_field)
	{
		goto noresult;
	}
	
	ApFoundArray=cJSON_CreateArray();
	for(i = 0;i<nrow;i++)
	{
		root=cJSON_CreateObject();
		cJSON_AddItemToArray(ApFoundArray,root);
		row = mysql_fetch_row(result);
		if(!row)
				break;
		for(j= 0;j<ncol;j++)
		{
			cJSON_AddStringToObject(root, my_field[j].name,row[j]==NULL ? "" :row[j]);
		}
	}
	
	output=cJSON_Print(ApFoundArray);

	cJSON_Delete(ApFoundArray);
	
	mysql_free_result(result);

	return output;

noresult:
	cste_mysqlclose(&my_con);
	return NULL;
}

void radio_test(MYSQL **my_con,char *mac)
{
	char *output=NULL;
	char APKEY[MYSQL_APKEY_LEN] = {0};
	int APTYPE=0;
	int GID = 0;
	char query[MAX_MYSQL_QUERY_LEN] ={0};

	cJSON *root = cJSON_CreateObject();
	
	cJSON *radio0 = cJSON_CreateObject();

	cJSON *radio1 = cJSON_CreateObject();
	
	cste_mysqlgetint(my_con, MYSQL_APLIST_TABLE,MYSQL_APTYPE_KEY_NAME,MYSQL_MAC_KEY_NAME,mac,&APTYPE);

	cste_mysqlgetint(my_con, MYSQL_APLIST_TABLE,MYSQL_GROUPID_KEY_NAME,MYSQL_MAC_KEY_NAME,mac,&GID);
	cste_mysqlgetstr(my_con, MYSQL_APLIST_TABLE,MYSQL_MANAGE_KEY_KEY_NAME,MYSQL_MAC_KEY_NAME,mac,APKEY,MYSQL_APKEY_LEN);
	
	cJSON_AddStringToObject(root, "action",ACTION_RADIOCONFIG);
	cJSON_AddStringToObject(root, "apMac",mac);

	cJSON_AddStringToObject(root, "key",APKEY);
	cJSON_AddStringToObject(root, "apName","TOTOLINK");
	
	if(MyGetField32(APTYPE,APTYPE_WIFI2G_START))
	{
		snprintf(query,MAX_MYSQL_QUERY_LEN,"select *from %s where gid=%d;",TBL_ID_TONAME(MYSQL_APCONFIG_WIFI0),GID);
		mysql_onerowtojson(my_con,radio0,query);
		cJSON_AddItemToObject(root,"radio0",radio0);
	}

	if(MyGetField32(APTYPE,APTYPE_WIFI5G_START))
	{	
		snprintf(query,MAX_MYSQL_QUERY_LEN,"select *from %s where gid=%d;",TBL_ID_TONAME(MYSQL_APCONFIG_WIFI0),GID);
		mysql_onerowtojson(my_con,radio1,query);
		cJSON_AddItemToObject(root,"radio1",radio1);
	}

	output=cJSON_Print(root);
	printf("@@@@@output is %s\n",output);
	free(output);
	cJSON_Delete(root);
	//cJSON_Delete(radio0);
	//cJSON_Delete(radio1);

	return;
}

void mysql_test(struct heartbeat_agent* agent)
{

#if 0

	char *output=NULL;
	cJSON *root = cJSON_CreateObject();
	cJSON *wlans = cJSON_CreateArray();
	
	cJSON_AddStringToObject(root, "apMac","123123123123123");
	mysqljsonarray(&(agent->my_con),wlans,"select *from WLAN_CONFIG where gid=1;");
	
	output=cJSON_Print(root);
	printf("output is %s\n",output);
	cJSON_AddItemToObject(root,"ssids",wlans);
	free(output);
	cJSON_Delete(root);


	//radio_test(&my_con,"00:A0:C6:00:D8:59");
	int apstate = 0;

	while(1)
	{
		cste_mysqlopen(&my_con);
		apstate = 0;
		cste_mysqlgetint(&my_con, MYSQL_APLIST_TABLE ,MSYQL_APSTATE_KEY_NAME,MYSQL_MAC_KEY_NAME,"00:A0:C6:00:D8:59",&apstate);
		printf("mysql_test:apstate is %d\n",apstate);
		cste_mysqlclose(&my_con);
	}
	
	//char *output =mysql_printjson(&my_con,"select * from APGROUP;");
	
	//printf("output is %s\n",output);
	
	cJSON  *root;
	cJSON  *radio;
	cJSON  *ssids;
	cJSON	*ssid;
	int i;
	char temp[10] = {0};
	
	root=cJSON_CreateObject();
	cJSON_AddStringToObject(root,"action","setradioconfig");
	cJSON_AddStringToObject(root,"status","0");
	radio = cJSON_CreateObject();
	cJSON_AddStringToObject(radio, "radioid",  "1");
	cJSON_AddStringToObject(radio, "txpower",  "100");
	cJSON_AddStringToObject(radio, "channel",  "1");
	//cste_mysqljsonarray();
	ssids = cJSON_CreateArray();
	mysqljsonarray(&my_con,ssids,"select * from WLAN_CONFIG where gid=1;");
	//for(i=0;i<2;i++)
	//{
	//	ssid = cJSON_CreateObject();
	//	snprintf(temp,10,"aaaaa%d",i);
	//	cJSON_AddStringToObject(ssid, "ssid",  temp);
	//	cJSON_AddStringToObject(ssid, "encryption",  "open");
	//	cJSON_AddItemToArray(ssids,ssid);
		
	//}
	
	cJSON_AddItemToObject(radio,"SSIDS",ssids);
	//int cou = mysql_onerowtojson(&my_con,radio,"select *from WIFI0_CONFIG where gid=2;");
	//printf("cou is %d\n",cou);
	//if(!mysql_onerowtojson(&my_con,radio,"select *from WIFI0_CONFIG where gid=2;"))
	//{
		//cJSON_AddItemToObject(root,"radio0","");
	//}else
	//{
		cJSON_AddItemToObject(root,"radio0",radio);
	//}
	//cJSON_AddItemToObject(root,"radio0",radio);

	
	char *output1= cJSON_Print(root);
	printf("output1 is %s\n",output1);
#endif
	
}

void ApHeartBeatcheck(struct heartbeat_agent* agent)
{
	char query[1024] ={0};
	cJSON *root =NULL;
	
	int uptime = 0,count  = 0;
	int apstate = 0,apstatenetwork = 0;
	
	update_apstate(RESET_COMMAND,MY_CONFIG_OK,&apstate);
	update_apstate(REBOOT_COMMAND,MY_CONFIG_OK,&apstate);
	update_apstate(UPGRADE_COMMAND,MY_CONFIG_OK,&apstate);
	update_apstate(AUTH_VERIFY,MY_CONFIG_OK,&apstate);

	update_apstate(NETWORK_STATE,MY_CONFIG_OK,&apstate);
	update_apstate(NETWORK_STATE,MY_CONFIG_OK,&apstatenetwork);

	cste_mysqlexec(&(agent->my_con),"update %s set %s=%s+1 where %s<%d;",TBL_ID_TONAME(MYSQL_APLIST_TABLE),MYSQL_HFTIMES_KEY_NAME,MYSQL_HFTIMES_KEY_NAME,MYSQL_HFTIMES_KEY_NAME,MAX_HFTIMES);
	//hftimes>6 and  same net work ap
	cste_mysqlexec(&(agent->my_con),"update %s set %s=%d where %s>%d AND %s>=%d;",TBL_ID_TONAME(MYSQL_APLIST_TABLE),MSYQL_APSTATE_KEY_NAME,apstate,
					MYSQL_HFTIMES_KEY_NAME,OFFLINE_HFTIMES,MSYQL_APSTATE_KEY_NAME,apstatenetwork);

	snprintf(query,sizeof(query),"select %s from %s where %s>%d",MYSQL_APID_KEY_NAME,TBL_ID_TONAME(MYSQL_APLIST_TABLE),MYSQL_HFTIMES_KEY_NAME,REMOVE_HFTIMES);
		
	root=cJSON_CreateArray();	
	mysqljsonarray(&(agent->my_con),root,query);
	for(count = 0;count<cJSON_GetArraySize(root);count++)
	{	
		cJSON *tempcjson =cJSON_GetArrayItem(root,count);
		char *id= websGetVar(tempcjson, T("id"), T("0"));
		if(atoi(id))
		{
			cste_mysqlexec(&(agent->my_con),"delete from  %s where %s=%s;",TBL_ID_TONAME(MYSQL_WLAN_STATUS),MYSQL_STATUS_APID,id);
			cste_mysqlexec(&(agent->my_con),"delete from  %s where %s=%s;",TBL_ID_TONAME(MYSQL_APSTATUS_WIFI0),MYSQL_STATUS_APID,id);
			cste_mysqlexec(&(agent->my_con),"delete from  %s where %s=%s;",TBL_ID_TONAME(MYSQL_APSTATUS_WIFI1),MYSQL_STATUS_APID,id);
			cste_mysqlexec(&(agent->my_con),"delete from  %s where %s=%s;",TBL_ID_TONAME(MYSQL_APLIST_TABLE),MYSQL_APID_KEY_NAME,id);
		}
	}
	cJSON_Delete(root);
	JobQueueAddJob(HEART_BEAT_INTERVAL, JOB_HEART_BEAT, ApHeartBeatcheck, NULL, agent);
}

static sigjmp_buf jmpbuf;

static void alarm_func()
{
     siglongjmp(jmpbuf, 1);
}

struct hostent *gngethostbyname(char *HostName, int timeout)
{
     struct hostent *lpHostEnt;
 
     signal(SIGALRM, alarm_func);
     if(sigsetjmp(jmpbuf, 1) != 0)
     {
           alarm(0);
           signal(SIGALRM, SIG_IGN);
           return NULL;
     }
	 
     alarm(timeout);
     lpHostEnt = gethostbyname(HostName);
     signal(SIGALRM, SIG_IGN);
 
     return lpHostEnt;
}

static int ipEncode(const char *src, unsigned char *dest)
{
	memset(dest, 0, 4);
	int a,b,c,d;
	
	sscanf(src, "%d.%d.%d.%d", &a,&b,&c,&d);
	*dest=a;
	*(dest+1)=b;
	*(dest+2)=c;
	*(dest+3)=d;
	
	return 0;
}
static int getApIpList(char *ipaddr)
{	
	char query[1024] ={0};
	char* output;
	cJSON *root=cJSON_CreateArray();

	MYSQL *my_con;
	
	cste_mysqlopen(&my_con);
	snprintf(query,sizeof(query),"select distinct ipaddr from %s;",TBL_ID_TONAME(MYSQL_APLIST_TABLE));
	mysqljsonarray(&my_con,root,query);

	cste_mysqlclose(&my_con);
	output =cJSON_Print(root);
	cJSON_Delete(root);
	if(strstr(output,ipaddr))
	{
		free(output);
		return 1;
	}
	else
	{
		free(output);
		return 0;
	}
}

static int getArpTable(char *ipaddr)
{
	char lanName[8] = {0},buff[128];

	FILE *fp = popen("arp -an", "r");
	
	if(!fp){
		return 0;
	}
	getLanIfName(lanName);
	fgets(buff, sizeof(buff), fp);
	while (fgets(buff, sizeof(buff), fp) != NULL) {
		if (strstr(buff,lanName)) 
		{
			if(strstr(buff,ipaddr))
			{
				pclose(fp);
				return 1;
			}			
		}
	}
	pclose(fp);
	return 0;
}

static int getIpList(char *gateway,char *mask,char *ipaddr)
{
	int i = 0,j = 0;
	char tmpipaddr[32] = {0};
	char network_addr[32] = {0};
	char network_broadcast[32] = {0};
	
	unsigned char  broadcastaddr[16],maskaddr[16],tmpip[16];
	unsigned int tmpmask = 0,mask_zero = 0,tmpaddr = 0;
	
	memset(network_addr,0,sizeof(network_addr));
	memset(network_broadcast,0,sizeof(network_broadcast));

	ipEncode(gateway,broadcastaddr);
	ipEncode(mask,maskaddr);
	
	for (i = 0; i < 4; i++) {
		tmpip[i] = broadcastaddr[i] & maskaddr[i];
    }
	sprintf(network_addr,"%d.%d.%d.%d",tmpip[0],tmpip[1],tmpip[2],tmpip[3]);

	tmpmask = maskaddr[0]*256*256*256+maskaddr[1]*256*256+maskaddr[2]*256+maskaddr[3];
	for (i = 0; i < 32; i++) {
		if(MyGetField32(tmpmask,i))
			break;
    }
	mask_zero = i;

	tmpaddr	= broadcastaddr[0]*256*256*256+broadcastaddr[1]*256*256+broadcastaddr[2]*256+broadcastaddr[3];

	for(i = 0;i<mask_zero;i++)
		MySetField32(tmpaddr,i);

	tmpip[0] = (tmpaddr>>24)&0xFF;
	tmpip[1] = (tmpaddr>>16)&0xFF;
	tmpip[2] = (tmpaddr>>8)&0xFF;
	tmpip[3] = (tmpaddr)&0xFF;
	sprintf(network_broadcast,"%d.%d.%d.%d",tmpip[0],tmpip[1],tmpip[2],tmpip[3]);

	unsigned char  start[16],end[16];
	unsigned char  range1[4096],range2[4096],range3[4096],range4[4096];
	unsigned char min,max;

	int i1 = 0,i2 = 0,i3 = 0,i4 = 0;
	int r1 = 0,r2 = 0,r3 = 0,r4 = 0;
	
	ipEncode(network_addr,start);
	ipEncode(network_broadcast,end);
	
    for (i = 0; i < 4; i++) {

        if (start[i] == end[i]) {
			if(i == 0)
				range1[r1++] = start[i];
			else if(i == 1)
				range2[r2++] = start[i];
			else if(i == 2)
				range3[r3++] = start[i];
			else if(i == 3)
				range4[r4++] = start[i];
        }	
		else {
			min = start[i]>end[i]?end[i]:start[i];
            max = start[i]>end[i]?start[i]:end[i];

			if(i == 3) min = 2;

            for (j = min; j <= max; j++) {
				if(i == 0)
					range1[r1++] = j;
				else if(i == 1)
					range2[r2++] = j;
				else if(i == 2)
					range3[r3++] = j;
				else if(i == 3)
					range4[r4++] = j;
            }
        }
    }
	for(i1 = 0;i1<r1;i1++){
		for(i2 = 0;i2<r2;i2++){
			for(i3 = 0;i3<r3;i3++){
				for(i4 = 0;i4<r4;i4++){
					bzero(tmpipaddr,sizeof(tmpipaddr));
					sprintf(tmpipaddr,"%d.%d.%d.%d",range1[i1],range2[i2],range3[i3],range4[i4]);
					if(!strcmp(tmpipaddr,network_addr)||!strcmp(tmpipaddr,network_broadcast)||!strcmp(tmpipaddr,gateway))
						continue;
					else if(getArpTable(tmpipaddr))
						continue;
					else if(getApIpList(tmpipaddr))
						continue;
					else{
						strcpy(ipaddr,tmpipaddr);
						return 1;	
					}
				}
			}
		}
	}
	return 0;
	
}

static int broadcastRouteInit( void )
{
	FILE *fp;
	char *ptr = NULL;
	char lanName[8] = {0},buffer[128] = {0},cmd[128] = {0};
	int found = 0;
	
	getLanIfName(lanName);
	sprintf(cmd,"netstat -nr | grep %s",lanName);
	fp = popen(cmd, "r");
	if (fp==NULL)
	{
		perror("popen");
		return found;
	}
	
	while (NULL != fgets(buffer, sizeof(buffer),fp))
	{
		ptr = strstr(buffer, BROADCAST_IP);
		if (ptr) {
			found = 1;
			break;
		}
	}
	pclose(fp);
	
	if ( 0 == found ){
		sprintf(cmd, "route add -host %s -iface -link %s",BROADCAST_IP,lanName);
		CsteSystem(cmd, CSTE_PRINT_CMD);
	}

	return 0;
}

static int broadcastInit(void)
{	
	int so_broadcast=1;
	int socket_fd;
	struct sockaddr_in myaddr;

	broad_cast_addr.sin_family=AF_INET;
	broad_cast_addr.sin_port=htons(BROADCAST_DPORT);
	broad_cast_addr.sin_addr.s_addr=inet_addr(BROADCAST_IP);
	bzero(&(broad_cast_addr.sin_zero),8);
	
    myaddr.sin_family=AF_INET;
    myaddr.sin_port=htons(BROADCAST_SPORT);
	myaddr.sin_addr.s_addr=htonl(INADDR_ANY);
//	myaddr.sin_addr.s_addr=inet_addr("192.168.10.1");
    bzero(&(myaddr.sin_zero),8);
	
	broadcastRouteInit();
    if((socket_fd=(socket(AF_INET,SOCK_DGRAM,0)))==-1) {
		perror("socket");
		return HB_FALSE;
    }
    setsockopt(socket_fd,SOL_SOCKET,SO_BROADCAST,&so_broadcast,sizeof(so_broadcast));
    if((bind(socket_fd,(struct sockaddr *)&myaddr,sizeof(struct sockaddr)))==-1) {
		perror("bind");
		return HB_FALSE;
    }
	broad_sk = socket_fd;
	return HB_TRUE;
}



void AcInit(void)
{
	int flag = 1;
	char buff[128];

	FILE *fp;
	
	fp = popen("ps -aux | grep mysql | grep -v grep", "r");
	
	if(fp){
		while (fgets(buff, sizeof(buff), fp) != NULL) {
			if (strstr(buff,"mysqld")) 
			{
				flag = 0; 
				break;		
			}
		}
		if(flag){
			printf("start mysql....\n");
			system("/usr/local/etc/rc.d/csac start");
			sleep(2);
		}
		pclose(fp);
	}

	flag = 1;
	
	fp = popen("df -h | grep tmpfs | grep -v grep", "r");
	
	if(fp){
		while (fgets(buff, sizeof(buff), fp) != NULL) {
			if (strstr(buff,"/usr/local/opnsense/cs/ac/webapi/firmware")) 
			{
				flag = 0;
				break;		
			}
		}
		if(flag){
			printf("Mount firmware partition type tmpfs");
			system("mkdir -p /usr/local/opnsense/cs/ac/webapi/firmware");
			system("/sbin/mount -o size=104857600 -t tmpfs tmpfs /usr/local/opnsense/cs/ac/webapi/firmware");
			sleep(2);
		}
		pclose(fp);
	}
	return;
	
}

void AcReset(int sig)
{

	if(SIG_ACRESET !=sig)
	{
		return;
		
	}
	
	system("/usr/local/etc/rc.d/csac stop");

	system("/sbin/umount /usr/local/opnsense/cs/ac/webapi/firmware");
	
	system("rm -rf /usr/local/opnsense/cs/ac/webapi/firmware");

	gRun = J_FALSE;
	
	return;
}

static void sendBroadCastScan(int sig)
{
	char lanName[8] = {0}, acIp[16] = {0}, acMask[16] = {0},tmp[16] = {0};
    cJSON *root = NULL;
	char *pub_buf = NULL;

	if(SIG_BROADCAST !=sig)
	{
		return;
	}
    root=cJSON_CreateObject();
	getLanIfName(lanName);
	getIfIp(lanName, acIp);
	getIfNetmask(lanName, acMask);
	cJSON_AddStringToObject(root,"ip",acIp);
	cJSON_AddStringToObject(root,"mask",acMask);
	cJSON_AddStringToObject(root,"action",ACTION_SCANAP);
	memset(tmp,0,sizeof(tmp));
	sprintf(tmp,"%d",GATEWAY_AC);
	cJSON_AddStringToObject(root,"type",tmp);
	cJSON_AddStringToObject(root,"version",ACVERSION);

	pub_buf =cJSON_Print(root);
	broadcastRouteInit();
	if(sendto(broad_sk,pub_buf,strlen(pub_buf), 0, (struct sockaddr *)&broad_cast_addr, sizeof(broad_cast_addr))<0){
		printf("[dbg]sendBroadCastScan error!\n");
	}
	cJSON_Delete(root);
	free(pub_buf);
	return ;
}

static void sendBroadCastSetIP(char *mac,char *ipaddr)
{
	char lanName[16] = {0},gateway[32] = {0},mask[32] = {0},temp[8] = {0};

	char *pub_buf = NULL;

	cJSON *root=cJSON_CreateObject();

	getLanIfName(lanName);
	getIfIp(lanName, gateway);
	getIfNetmask(lanName, mask);
	
	cJSON_AddStringToObject(root,"mac",mac);
	cJSON_AddStringToObject(root,"ip",ipaddr);
	cJSON_AddStringToObject(root,"mask",mask);
	cJSON_AddStringToObject(root,"dhcp","0");
	cJSON_AddStringToObject(root,"gateway",gateway);
	cJSON_AddStringToObject(root,"dns",gateway);

	sprintf(temp,"%d",GATEWAY_AC);
	cJSON_AddStringToObject(root,"type",temp);
	cJSON_AddStringToObject(root,"action",ACTION_SETAPIP);
	cJSON_AddStringToObject(root,"version",ACVERSION);

	pub_buf =cJSON_Print(root);
	cJSON_Delete(root);
	broadcastRouteInit();
	if(sendto(broad_sk,pub_buf,strlen(pub_buf), 0, (struct sockaddr *)&broad_cast_addr, sizeof(broad_cast_addr))<0){
		printf("[dbg]sendBroadCast error!\n");
	}
	free(pub_buf);
	return ;
}

static void oneKeySetApIp(int sig)
{
	MYSQL *my_con;
	int i = 0,apstate = 0;
	char lanName[8] = {0},tmpBuf[MAX_BUF_SIZE]={0},APMAC[18] ={0},gateway[32] = {0},mask[32] = {0},ipaddr[32] = {0};
	
	if(SIG_SETAPIP !=sig)
	{
		return;
	}
	cJSON *root=cJSON_CreateObject();
	memset(tmpBuf,0,sizeof(tmpBuf));
	getStrFromFile("/tmp/apipsetting", tmpBuf);
	
	root=cJSON_Parse(tmpBuf);
	if(!root)
	{
		cJSON_Delete(root);
		printf("[oneKeySetApIp]/tmp/apipsetting not json!\n");
		return ;
	}
	getLanIfName(lanName);
	getIfIp(lanName, gateway);
	getIfNetmask(lanName, mask);

	cste_mysqlopen(&my_con);
	char *apmac = websGetVar(root, T("apmac"), T(""));
	
	update_apstate(NETWORK_STATE,MY_CONFIG_OK,&apstate);
	while((getNthValueSafe(i++, apmac, ',', APMAC, sizeof(APMAC)) != -1))
	{
		bzero(ipaddr,sizeof(ipaddr));
		if(getIpList(gateway,mask,ipaddr))
		{
			printf("set ipaddr='%s',apmac='%s';\n",ipaddr,APMAC);
			cste_mysqlexec(&my_con,"update %s set ipaddr='%s',apstate=apstate|%d where apmac='%s';",
						TBL_ID_TONAME(MYSQL_APLIST_TABLE),ipaddr,apstate,APMAC);
			
			sendBroadCastSetIP(APMAC,ipaddr);
		}
		else
		{
			break;
		}
	}
	cste_mysqlclose(&my_con);
	cJSON_Delete(root);
}

int main(int argc, char** argv)
{
	struct heartbeat_agent agent;
	
	MainInit(&agent);
	(void) signal(SIGTERM,MainGracefulExit);
	(void) signal(SIG_ACRESET,AcReset);
	(void) signal(SIG_BROADCAST,sendBroadCastScan);
	(void) signal(SIG_SETAPIP,oneKeySetApIp);
	//AcInit();
	JobQueueInit();
	JobQueueDebug(J_FALSE);
	cste_mysqlopen(&(agent.my_con));
	if(!HeartBeatSockInit(&agent))
	{
		printf("HeartBeatSockInit:Can't create heartbeat handle socket\n");
		exit(1);
	}
	if(!broadcastInit())
	{
		printf("broadcastInit:Can't create broadcast handle socket\n");
		exit(1);
	}
	//mysql_test(&agent);
	ApHeartBeatcheck(&agent);

	if(!JobQueueRegisterSocket(agent.socket,(void*)HeartBeatReceive,(void *)&agent))
	{
		printf("heartbeatAgent:Can't register socket to job queue\n");
		exit(1);
	}
	if(!JobQueueRegisterSocket(broad_sk,(void*)HeartBroadcastReceive,(void *)&agent))
	{
		printf("heartbeatAgent:Can't register socket to job queue\n");
		exit(1);
	}

	while(gRun == J_TRUE) {
		JobQueueExecutionLoop();
	}
	
	close(agent.socket);
	
	cste_mysqlclose(&(agent.my_con));

	printf("main exit!!!\n");
	JobQueueDeleteAllJob();
	
	return 0;
}
