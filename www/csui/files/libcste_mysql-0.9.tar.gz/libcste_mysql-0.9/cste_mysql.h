

#ifndef __CSTE_MY_SQL_H__
#define __CSTE_MY_SQL_H__

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <mysql/mysql.h>
#include <cJSON.h>
#include <stdarg.h>



/*mysql commmon*/
#define MYSQL_DIR "/tmp/data/"
#define MYSQL_LOCALHOST "localhost"
#define MYSQL_PORT 3306
#define MYSQL_USERNAME "root"
#define MYSQL_PASSWORD ""
#define MYSQL_SOCK "/var/run/mysqld.sock"
#define MYSQL_DB "csgateway"
#define DEFAULT_MANAGE_KEY "csapkey2017"
#define SESSIONOVER "SessionOver"

#define HEART_BEAT_INTERVAL  30

#define OFFLINE_HFTIMES		6

#define REMOVE_HFTIMES		12

#define	MAX_HFTIMES			100

/*-----------------------------------------------------------------*/


/*mysql table*/
#define MYSQL_APLIST_TABLE_NAME 			"APLIST"
#define MYSQL_APSTATUS_WIFI0_NAME 			"WIFI0_STATUS"
#define MYSQL_APSTATUS_WIFI1_NAME 			"WIFI1_STATUS"
#define MYSQL_WLAN_STATUS_NAME				"WLAN_STATUS"
#define MYSQL_APGROUP_TABLE_NAME 			"APGROUP"
#define MYSQL_APCONFIG_WIFI0_NAME 			"WIFI0_CONFIG"
#define MYSQL_APCONFIG_WIFI1_NAME 			"WIFI1_CONFIG"
#define MYSQL_WLAN_CONFIG_NAME 				"WLAN_CONFIG"
#define MYSQL_AP_UPGRADE_NAME 				"AP_UPGRADE"


enum cste_table_i
{
	MYSQL_APLIST_TABLE=0,
	MYSQL_APSTATUS_WIFI0,
	MYSQL_APSTATUS_WIFI1,
	MYSQL_WLAN_STATUS,
	MYSQL_APGROUP_TABLE,
	MYSQL_APCONFIG_WIFI0,
	MYSQL_APCONFIG_WIFI1,
	MYSQL_WLAN_CONFIG,
	MYSQL_AP_UPGRADE,
	MYSQL_MAX_TABLE
};

#define TBL_ID_TONAME(id)	 \
((id == MYSQL_APLIST_TABLE) ? MYSQL_APLIST_TABLE_NAME : \
(id == MYSQL_APSTATUS_WIFI0) ? MYSQL_APSTATUS_WIFI0_NAME : \
(id == MYSQL_APSTATUS_WIFI1) ? MYSQL_APSTATUS_WIFI1_NAME : \
(id == MYSQL_WLAN_STATUS) ? MYSQL_WLAN_STATUS_NAME : \
(id == MYSQL_APGROUP_TABLE) ? MYSQL_APGROUP_TABLE_NAME : \
(id == MYSQL_APCONFIG_WIFI0) ? MYSQL_APCONFIG_WIFI0_NAME : \
(id == MYSQL_APCONFIG_WIFI1) ? MYSQL_APCONFIG_WIFI1_NAME : \
(id == MYSQL_WLAN_CONFIG) ? MYSQL_WLAN_CONFIG_NAME : \
(id == MYSQL_AP_UPGRADE) ? MYSQL_AP_UPGRADE_NAME: "Unknown Talbe")

/*-----------------------------------------------------------------*/
/*MYSQL common def*/
#define MAX_MYSQL_VALUE_LEN		512
#define MAX_MYSQL_QUERY_LEN		1024
#define MAX_MYSQL_GROUP_NAME_LEN	18
#define MYSQL_MAC_LEN			6
#define MYSQL_MAC_STR_LEN		18
#define MYSQL_IP_STR_LEN		16
#define MYSQL_APKEY_LEN			32
#define MYSQL_CSID_LEN			32

#define MySetField32(val,start)  (val |=(1<<start))

#define MyClearField32(val,start) (val &=(~(1<<start)))

#define MyGetField32(val,start) ((val&(1<<start))>>start)


/*MYSQL_APLIST_TABLE_NAME*/
#define MYSQL_MAC_KEY_NAME					"apmac"
#define MYSQL_PASSWORD_KEY_NAME				"password"
#define MYSQL_MANAGE_KEY_KEY_NAME			"apkey"
#define MSYQL_APSTATE_KEY_NAME				"apstate"
#define MYSQL_CONFIG_KEY_NAME				"config"
#define	MYSQL_APTYPE_KEY_NAME				"aptype"
#define MYSQL_APNAME_KEY_NAME				"apname"
#define MYSQL_LEDSTATE_KEY_NAME			    "ledstate"

#define MYSQL_HFTIMES_KEY_NAME				"hftimes"
#define MYSQL_APID_KEY_NAME					"id"

/*MYSQL_STATUS*/
#define MYSQL_STATUS_APID					"apid"

/*-----------------------------------------------------------------*/



/*MYSQL_APGROUP_TABLE_NAME*/
#define MYSQL_GROUPNAME_KEY_NAME			"groupname"
#define MYSQL_GROUPID_KEY_NAME				"gid"
#define MYSQL_TOTALAP_GROUP_NAME			"totalap"
#define MYSQL_ONLINEAP_GROUP_NAME			"onlineap"
#define MYSQL_DEFAULT_GROUP_NAME			"default"


/*-----------------------------------------------------------------*/

/*MYSQL_WIFI_CONFIG*/
#define RADIO0	"RADIO0"
#define RADIO1	"RADIO1"

/*MYSQL_WLAN_CONFIG*/
#define SSIDS_STR	"SSIDS"



/*-----------------------------------------------------------------*/



/*MYSQL_AP_UPGRADE*/

#define MSYQL_FILE_PATH_KEY_NAME			"filepath"
#define MYSQL_CSID_KEY_NAME					"csid"
#define MYSQL_SVNNUM_KEY_NAME				"svnnum"
#define MYSQL_BULIDDATE_KEY_NAME			"builddate"





/* ACTION define*/
#define ACTION_COMPARE(action,macro) strcmp(action,macro)

#define ACTION_GET			"get"
#define ACTION_FMUPDATE		"SetUpgrade"
#define ACTION_RESET		"SetReset"
#define ACTION_REBOOT		"SetReboot"
#define ACTION_RADIOCONFIG	"SetRadioConfig"
#define ACTION_WLANCONFIG	"SetWlanConfig"
#define ACTION_SYSCONFIG	"SetSysConfig"

#define SESSIONOVER 		"SessionOver"

/*-----------------------------------------------------------------*/

typedef enum{
	ONLINE_STATE = 0,
	UPGRADE_COMMAND,
	RESET_COMMAND,
	REBOOT_COMMAND,
	RADIO_CONFIG,
	WLAN_CONFIG,
	SYSTEM_CONFIG,
	AUTH_VERIFY,
	NETWORK_STATE,
	MAX_STATE_NUM,
}AP_STATE_FLAG;

#define AP_CONFIG_OK_VALUE ((1<<MAX_STATE_NUM) -1 )

#define APTYPE_WIFI2G_START 0
#define	APTYPE_WIFI5G_START 1

typedef enum
{
	MY_CONFIG_NEED = 0,
	MY_CONFIG_OK =	1,
}CONFIG_STATE;

typedef enum 
{
	STATE_ERROR=-1,
	STATE_FALSE=0,
	STATE_TRUE=1
}STATE;

typedef enum 	
{
	AUTH_SUCCESS = 0,
	AUTH_FAIL
}AUTH_STATE;

typedef enum 
{
	AP_RUN = 0,
	AP_SYSC,
}AP_STATE;


void cste_mysqlopen(MYSQL **my_con);
void cste_mysqlclose(MYSQL **my_con);
void cste_mysqlerrorlog(MYSQL **my_con,const char *action);
int cste_mysqlexec(MYSQL **my_con,const char *fmt,...);
int cste_mysqlgetstr(MYSQL **my_con,int table_id,const char *key,const char *whererange,const char *range_value,char*value,int len);
void cste_mysqlgetint(MYSQL **my_con,int table_id,const char *key,const char *whererange,const char *range_value,int *value);
void update_apstate(AP_STATE_FLAG start,CONFIG_STATE state,int *apstate);

int mysql_onerowtojson(MYSQL **my_con,cJSON *root,char *query);
int mysqljsonarray(MYSQL **mycon,cJSON *array,char *query);

void update_configneed_by_gid(MYSQL **my_con,int config_value,int gid);
int cste_mysqlgettable(MYSQL **my_con,char *query,int *nrow, int *ncol, char **result);

#endif


