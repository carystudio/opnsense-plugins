
#include "cste_mysql.h"



#if 0
int cste_initmysql(void)
{
	int i=0;
	char logbuf[128] ={0};
	mysql_init(my_con);
	
    if(!mysql_real_connect(my_con,MYSQL_LOCALHOST, MYSQL_USERNAME,MYSQL_PASSWORD,MYSQL_DB, MYSQL_PORT, NULL,0))
    {
			if( my_con != NULL )
			{ 
        	mysql_close(my_con);
			}
			free(my_con);
			printf("mysql connect fail. host[%s] port[%d] username[%s] password[%s]\n", MYSQL_LOCALHOST, MYSQL_PORT, MYSQL_USERNAME, MYSQL_PASSWORD);
    }
	return 0;
}

#endif

void cste_mysqlerrorlog(MYSQL **my_con,const char *action)
{
	printf("cste mysql:[%s] :%s\n",action,mysql_error(*my_con));
}

void cste_mysqlfixedtable(MYSQL **my_con,int table_id)
{
	char query[MAX_MYSQL_QUERY_LEN]={0};
	char default_table[MAX_MYSQL_GROUP_NAME_LEN] = {0};
	int  default_gid = 0;
	
	switch(table_id)
	{
		case MYSQL_APGROUP_TABLE:
			if(cste_mysqlgetstr(my_con,table_id,MYSQL_GROUPNAME_KEY_NAME,MYSQL_GROUPID_KEY_NAME,"1",default_table,MAX_MYSQL_GROUP_NAME_LEN))
			{
				if(strcmp(default_table,MYSQL_DEFAULT_GROUP_NAME)==0)
				{
					return;
				}else
				{
					printf("cste_mysqlfixedtable:default apgroup error!\n");
				}
				
			}else
			{
				cste_mysqlexec(my_con,"insert into %s (gid,groupname, totalap,onlineap) "
		               		"VALUES ('0', '%s', '0', '0');",
		               TBL_ID_TONAME(table_id),MYSQL_DEFAULT_GROUP_NAME);
			}
			break;
		case MYSQL_APCONFIG_WIFI0:
		case MYSQL_APCONFIG_WIFI1:
		{
			cste_mysqlgetint(my_con,table_id,MYSQL_GROUPID_KEY_NAME,MYSQL_GROUPID_KEY_NAME,"1",&default_gid);
			if(1== default_gid)
			{
				return;
			}else
			{
				cste_mysqlexec(my_con,"insert into %s (gid,country,wirelessmode, htmode,channel,txpower,beacon) "
		               		"VALUES ('1', 'CN', '%d', '%d','0',100,100);",
		               TBL_ID_TONAME(table_id),table_id== MYSQL_APCONFIG_WIFI0 ? 9 : 14,table_id== MYSQL_APCONFIG_WIFI0 ? 1 : 2);
			}
		}
		default:
			break;
	}
	return;
}

void cste_mysqlopen(MYSQL **my_con)
{
	if(!my_con) return;
	*my_con = mysql_init(NULL);
	if(*my_con == NULL)
	{
		return;
	}

    if(!mysql_real_connect(*my_con,MYSQL_LOCALHOST, MYSQL_USERNAME,MYSQL_PASSWORD,MYSQL_DB, MYSQL_PORT, NULL,0))
    {
    	printf("connect mysql fail. host[%s] port[%d] username[%s] password[%s]\n", MYSQL_LOCALHOST, MYSQL_PORT, MYSQL_USERNAME, MYSQL_PASSWORD);
			cste_mysqlclose(my_con);
			return ;
    }else{
    	printf("connect mysql success\n");
    }
}


void cste_mysqlclose(MYSQL **my_con)
{
	if(*my_con) {
		mysql_close(*my_con);
		*my_con = NULL;
	}
}


int cste_mysqlgetstr(MYSQL **my_con,int table_id,const char *key,const char *whererange,const char *range_value,char*value,int len)
{
	int ret;
	MYSQL_RES *res	= NULL;
	char query[MAX_MYSQL_QUERY_LEN]={0};
	int line;
	MYSQL_ROW row;
	int i, k,field;

	if((!key)||(!whererange)||(!range_value)||(!value))
	{
		return 0;
	}
	
	snprintf(query,sizeof(query),"select %s from %s where %s = '%s';",key,TBL_ID_TONAME(table_id),whererange,range_value);

	//printf("cste_mysqlgetstr query %s\n",query);
	ret = mysql_query(*my_con,query);

	if(ret)
	{
		cste_mysqlerrorlog(my_con,"Query get str");
		return 0;
	}
	
	res = mysql_store_result(*my_con);
	if(res)
	{
		if((mysql_num_fields(res) != 1) || (mysql_field_count(*my_con)!=1))
		{
			printf("cste_mysqlgetstr:result incorrect\n");
		}else
		{
			//printf("cste_mysqlgetstr:4444444444\n");
			row = mysql_fetch_row(res);
			//printf("cste_mysqlgetstr:555555555\n");
			if(row)
			{
				//printf("cste_mysqlgetstr:666666\n");
				mysql_free_result(res);
				//printf("cste_mysqlgetstr:77777\n");
				res = NULL;
				if(row[0])
				{
					//printf("cste_mysqlgetstr:8888888\n");
					snprintf(value,len,"%s",row[0]);
					//printf("strlen(row[0]) is %d\n",strlen(row[0]));
					return strlen(row[0]);
				}
				
			}
			
		}
	}
	
	if(res)
	{	
		mysql_free_result(res);
	}
	return 0;
}

void cste_mysqlgetint(MYSQL **my_con,int table_id,const char *key,const char *whererange,const char *range_value,int *value)
{
	char value_str[MAX_MYSQL_VALUE_LEN];

	if((!key)||(!whererange)||(!range_value) ||(!value))
	{
		return;
	}

	memset(value_str,0,MAX_MYSQL_VALUE_LEN);
	
	if (0 == cste_mysqlgetstr(my_con,table_id,key,whererange,range_value,value_str,MAX_MYSQL_VALUE_LEN))
	{
		return;
	}

	*value = atoi(value_str);
	return;
}



int cste_mysqlexec(MYSQL **my_con,const char *fmt,...)
{
	char query[MAX_MYSQL_QUERY_LEN]={0};
	int ret;
	va_list argptr;

	va_start(argptr, fmt);
	vsprintf(query,fmt,argptr);
	va_end(argptr);
	
	printf("query:%s\n", query);
	ret = mysql_query(*my_con,query);

	if(ret)
	{
		cste_mysqlerrorlog(my_con,"Query mysqlexec");
	}
	return ret;
}


//Sql_Print

char **cste_mysqlgetrow(void *result)
{
	MYSQL_RES *res_set = (MYSQL_RES *)result;

	if(!res_set) return NULL;

	return mysql_fetch_row(res_set);
}


char *cste_mysqlgetfields(char *result,int col)
{
	MYSQL_FIELD *my_field =NULL;
	MYSQL_RES *my_res = (MYSQL_RES *)result;
	
	my_field = mysql_fetch_fields(my_res);
	if(my_field == NULL)
	{
		return NULL;
	}else
	{
		printf("123123123 my_field->name\n");
		return my_field->name;
	}
	
	int j;
	printf("cste_mysqlgetfields is %d addr is %d\n",col,result);
	
	for(j=0; j<col; j++)
	{
		printf("%s, ", my_field[j].name);
	}
	  
	  printf("\n-------------------------------------\n\n");
}

int cste_mysqlgettable(MYSQL **my_con,char *query,int *nrow, int *ncol, char **result)
{
	int ret;
	int i,j;
	//MYSQL_RES *res_set = NULL;


	if(nrow==NULL || ncol==NULL)
		goto __err;

	*nrow = 0;
	*ncol = 0;
	*result = NULL;
	
	ret = cste_mysqlexec(my_con,query);

	if(ret)
		goto __err;

	*result = mysql_store_result(*my_con);
	
	if(*result) 
	{
		*nrow = (int)mysql_num_rows(*result);
		*ncol = (int)mysql_num_fields(*result);
	}
	else
		goto __err;

	return 1;

__err:
	*nrow = 0;
	*ncol = 0;
	*result = NULL;
	return 0;
	
}

int cste_createdefaultradio(MYSQL **my_con,int gid)
{
	int mygid = 0;
	int i;
	char gid_str[32] = {0};

	snprintf(gid_str,32,"%d",gid);
	cste_mysqlgetint(my_con,MYSQL_APCONFIG_WIFI0,MYSQL_GROUPID_KEY_NAME,MYSQL_GROUPID_KEY_NAME,gid_str,&mygid);
	
	if(gid==mygid)
	{
		//no need to create;
		return 0;
	}

	cste_mysqlexec(my_con,"insert into %s (gid,country,wirelessmode, htmode,channel,txpower,beacon) "
           		"VALUES ('%d','CN','9','0','0','100','100');",
           TBL_ID_TONAME(MYSQL_APCONFIG_WIFI0),gid);
	
	cste_mysqlexec(my_con,"insert into %s (gid,country,wirelessmode, htmode,channel,txpower,beacon) "
           		"VALUES ('%d','CN','14','2','0','100',100);",
           TBL_ID_TONAME(MYSQL_APCONFIG_WIFI1),gid);
	
	return 0;
}

void update_apstate(AP_STATE_FLAG start,CONFIG_STATE state,int *apstate)
{
	
	if(state)
	{
		MySetField32(*apstate,start);
	}else
	{
		MyClearField32(*apstate,start);
	}
	
	return;
}


void update_apstate_by_action(char *action,CONFIG_STATE state,int *apstate)
{
	if(!ACTION_COMPARE(action,ACTION_RADIOCONFIG))
	{
		update_apstate(RADIO_CONFIG,state,apstate);
	}else if(!ACTION_COMPARE(action,ACTION_WLANCONFIG))
	{
		update_apstate(WLAN_CONFIG,state,apstate);
	}else if(!ACTION_COMPARE(action,ACTION_SYSCONFIG))
	{
		update_apstate(SYSTEM_CONFIG,state,apstate);
	}

	return;
}


int mysql_onerowtojson(MYSQL **my_con,cJSON *root,char *query)
{
	char *result = NULL;
	MYSQL_FIELD *my_field =NULL;
	MYSQL_ROW row;
	
	int  ret=0, nrow,ncol,j;

	int count = 0;
	
	ret = cste_mysqlgettable(my_con,query,&nrow,&ncol,&result);
	
	if((!ret)||(!nrow)||(!result))
	{
		goto noresult;
	}
	
	my_field = mysql_fetch_fields(result);
	if(!my_field)
	{
		goto noresult;
	}
	printf("mysql_rowtojson nrow is %d\n",nrow);
	if(nrow != 1)
	{
		printf("nrow is not only one\n");
		goto noresult;
	}

	row = mysql_fetch_row(result);
	if(!row)
	{
		goto noresult;
	}
	for(j= 0;j<ncol;j++)
	{
		printf("my_field[j].name is %s value is %s\n",my_field[j].name,row[j]==NULL ? "" :row[j]);
		cJSON_AddStringToObject(root, my_field[j].name,row[j]==NULL ? "" :row[j]);
		count++;
	}


	#if 0
	for(i = 0;i<nrow;i++)
	{

		//cJSON_AddItemToArray(ApFoundArray,root);
		row = mysql_fetch_row(result);
		if(!row)
				break;
		for(j= 0;j<ncol;j++)
		{
			printf("my_field[j].name is %s value is %s\n",my_field[j].name,row[j]==NULL ? "" :row[j]);
			//cJSON_AddStringToObject(root, my_field[j].name,row[j]==NULL ? "" :row[j]);
		}
	}
	#endif
	

noresult:
	if(result)
	{
		
		mysql_free_result(result);
	}
	//cste_mysqlclose(&my_con);
	return count;
}

int mysqljsonarray(MYSQL **my_con,cJSON *array,char *query)
{
	char *result = NULL;
	MYSQL_FIELD *my_field =NULL;
	MYSQL_ROW row;
	int count = 0;
	int  ret=0, nrow,ncol, i, j;
	cJSON *root;
	
	ret = cste_mysqlgettable(my_con,query,&nrow,&ncol,&result);
	if((!ret)||(!nrow)||(!result))
	{
		goto noresult;
	}
	
	my_field = mysql_fetch_fields(result);
	if(!my_field)
	{
		goto noresult;
	}
	
	for(i = 0;i<nrow;i++)
	{
		root=cJSON_CreateObject();
		cJSON_AddItemToArray(array,root);
		count++;
		row = mysql_fetch_row(result);
		if(!row)
				break;
		for(j= 0;j<ncol;j++)
		{
			cJSON_AddStringToObject(root, my_field[j].name,row[j]==NULL ? "" :row[j]);
		}
	}

noresult:
	if(result)
	{
		
		mysql_free_result(result);
	}
	return count;
}


void update_configneed_by_gid(MYSQL **my_con,int config_value,int gid)
{

	/*no need update offline ap status*/
	cste_mysqlexec(my_con,"update %s set %s=%s&%d where %s=%d and %s < %d;",TBL_ID_TONAME(MYSQL_APLIST_TABLE),MSYQL_APSTATE_KEY_NAME,MSYQL_APSTATE_KEY_NAME,
																config_value,MYSQL_GROUPID_KEY_NAME,gid,MYSQL_HFTIMES_KEY_NAME,OFFLINE_HFTIMES);
}

