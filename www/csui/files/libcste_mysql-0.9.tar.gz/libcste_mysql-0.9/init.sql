﻿CREATE DATABASE IF NOT EXISTS csgateway DEFAULT CHARSET utf8 COLLATE utf8_general_ci;
use csgateway;

CREATE TABLE APLIST (
			id int unsigned not null primary key auto_increment,
			apname varchar(32),
			apmac varchar(18),
			ipaddr varchar(18),
			netmask varchar(18),
			gateway varchar(18),
			pridns varchar(18),
			secdns varchar(18),
			apstate int default 0,
			ledstate int default 1,
			apkey varchar(32) default 'csapkey2017',
			csid varchar(32),
			model varchar(10),
			svnnum int,
			builddate varchar(10),
			uptime varchar(20),
			softver varchar(10),
			timestamp varchar(20) default '1970-01-01 08:00:00',
			aptype int,
			username varchar(10) default 'admin',
			password varchar(10) default 'admin',
			gid int default 1,
			hftimes int default 0
);
			
CREATE TABLE WIFI0_STATUS (
			id int unsigned not null primary key auto_increment,
			gid int default 1,
			apid int,
			country varchar(2),
			wirelessmode int default 9,
			htmode int default 0,
			channel int default 0,
			txpower int default 100,
			beacon int default 100
);

		
CREATE TABLE WIFI1_STATUS (
			id int unsigned not null primary key auto_increment,
			gid int default 1,
			apid int,
			country varchar(2),
			wirelessmode int default 14,
			htmode int default 2,
			channel int default 0,
			txpower int default 100,
			beacon int default 100
);
			
CREATE TABLE WLAN_STATUS (
			id int unsigned not null primary key auto_increment,
			gid int default 1,
			apid int,
			usefor int,
			ssid varchar(32),
			hide int default 0,
			isolate int default 0,
			encryption int default 0,
			passphrase varchar(64),
			stanum int default 32,
			vlanid int default 0
);
		
			
CREATE TABLE APGROUP (
			gid int unsigned not null primary key auto_increment,
			groupname varchar(18),
			totalap int default 0,
			onlineap int default 0
);

		
CREATE TABLE WIFI0_CONFIG (
			id int unsigned not null primary key auto_increment,
			gid int,
			country varchar(2),
			wirelessmode int,
			htmode int,
			channel int default 0,
			txpower int default 100,
			beacon int default 100
);

CREATE TABLE WIFI1_CONFIG (
			id int unsigned not null primary key auto_increment,
			gid int,
			country varchar(2),
			wirelessmode int,
			htmode int,
			channel int default 0,
			txpower int default 100,
			beacon int default 100
);
			
CREATE TABLE WLAN_CONFIG (
			wid int unsigned not null primary key auto_increment,
			usefor int,
			gid int default 1,
			ssid varchar(32),
			hide int default 0,
			isolate int default 0,
			encryption int default 0,
			passphrase varchar(64),
			stanum int,
			vlanid int default 0
);

		
CREATE TABLE AP_UPGRADE (
			id int unsigned not null primary key auto_increment,
			csid varchar(32),
			svnnum int,
			builddate varchar(10),
			filepath varchar(512)
);

